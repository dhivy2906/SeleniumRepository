package pages;

import org.openqa.selenium.By;

import base.PSM;

public class WelcomePage extends PSM{
	
	public LoginPage clickLogoutButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}
	
	public HomePage clickCrmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
	}
	
	
}
