package pages;

import org.openqa.selenium.By;

import base.PSM;

public class LoginPage extends PSM{

	public LoginPage enterUsername() {
		System.out.println("driver instance in enter username  "+driver);
		driver.findElement(By.id("username")).sendKeys("demosalesmanager");
		// use return type for page navigation
//		LoginPage lp = new LoginPage();
//		return lp;
//		return new LoginPage();
		return this;
	}
	
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	
	public WelcomePage clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}
	
}
