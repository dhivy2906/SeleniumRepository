package pages;

import org.openqa.selenium.By;

import base.PSM;

public class HomePage extends PSM{
	
	public void clickLeadsTab() {
		driver.findElement(By.linkText("Leads")).click();
	}
	
	public void clickAccountsTab() {
		
	}

}
